package com.issuetracker.userservice.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.issuetracker.userservice.dto.SignUpRequest;
import com.issuetracker.userservice.entity.Role;
import com.issuetracker.userservice.repository.UserRepository;
import com.issuetracker.userservice.service.UserService;

/**
 * Adds a few demo users the first time the service starts, so there is data to show straight away.
 *
 * CommandLineRunner.run() is called once, right after the application has started.
 * It only inserts when the table is EMPTY, so restarting the service never creates duplicates.
 * The users go through userService.signUp(), so their passwords are BCrypt-hashed like any other user's.
 *
 * On a fresh database they get ids 1-4 (the Project and Issue services' demo data rely on that):
 *   1 Priya Sharma  - PROJECT_OWNER - priya@its.com  / Owner@123
 *   2 Karan Mehta   - PROJECT_OWNER - karan@its.com  / Owner@123
 *   3 Rahul Verma   - ASSIGNEE      - rahul@its.com  / Assignee@123
 *   4 Ananya Iyer   - ASSIGNEE      - ananya@its.com / Assignee@123
 */
@Component
public class DemoDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoDataLoader.class);

    private final UserRepository userRepository;
    private final UserService userService;

    @Autowired
    public DemoDataLoader(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            log.info("Users already exist - demo data not loaded");
            return;
        }

        userService.signUp(new SignUpRequest("Priya Sharma", "priya@its.com", "Owner@123", null, Role.PROJECT_OWNER));
        userService.signUp(new SignUpRequest("Karan Mehta", "karan@its.com", "Owner@123", null, Role.PROJECT_OWNER));
        userService.signUp(new SignUpRequest("Rahul Verma", "rahul@its.com", "Assignee@123", null, Role.ASSIGNEE));
        userService.signUp(new SignUpRequest("Ananya Iyer", "ananya@its.com", "Assignee@123", null, Role.ASSIGNEE));

        log.info("Demo users loaded (2 project owners, 2 assignees)");
    }
}

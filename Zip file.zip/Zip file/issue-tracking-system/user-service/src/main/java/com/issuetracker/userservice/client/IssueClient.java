package com.issuetracker.userservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client for the Issue Service (Milestone 5 - inter-service communication).
 *
 * We only write this INTERFACE, using the same annotations as a controller. At start-up Spring Cloud
 * OpenFeign generates the implementation. When getIssuesByAssignee(3) is called it:
 *   1. asks Eureka (through Spring Cloud LoadBalancer) where "issue-service" is running -> localhost:8083
 *   2. sends GET http://localhost:8083/api/issues/assignee/3
 *   3. turns the JSON answer into a List<IssueDto>
 * name = "issue-service" is the other service's spring.application.name - no host or port is hard-coded.
 *
 * If the Issue Service is down, the call throws a FeignException, which GlobalExceptionHandler turns
 * into 503 Service Unavailable.
 */
@FeignClient(name = "issue-service")
public interface IssueClient {

    @GetMapping("/api/issues/assignee/{assigneeId}")
    List<IssueDto> getIssuesByAssignee(@PathVariable("assigneeId") Integer assigneeId);
}

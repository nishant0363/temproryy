package com.issuetracker.userservice.dto;

/**
 * Response of a successful login.
 * The user's role is included so a frontend can open the right dashboard
 * (Project Owner dashboard or Assignee dashboard) - that redirect is a frontend job.
 */
public record LoginResponse(
        String message,
        UserResponse user) {
}

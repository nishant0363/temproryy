package com.issuetracker.userservice.entity;

/**
 * The two kinds of users in the Issue Tracking System.
 *
 * The database column "role" is a TINYINT (see the DB design), so the role is stored as a number:
 * the position of the constant in this list (@Enumerated(EnumType.ORDINAL) on User.role).
 *   PROJECT_OWNER = 0, ASSIGNEE = 1
 * Because the number is the position, never re-order these constants - only add new ones at the end.
 * In JSON requests and responses the role is always written as text, e.g. "PROJECT_OWNER".
 */
public enum Role {
    PROJECT_OWNER,  // stored as 0 - creates projects and issues, assigns issues
    ASSIGNEE        // stored as 1 - works on assigned issues and updates their status
}

package com.issuetracker.userservice.dto;

import com.issuetracker.userservice.entity.Role;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * JSON body of POST /api/users (sign up).
 *
 * A Java "record" is a small, read-only data class: Java generates the constructor, the accessors
 * (name(), email() ...), equals, hashCode and toString for us.
 *
 * The validation annotations are checked automatically because the controller marks the body with @Valid.
 * If any rule fails, Spring throws MethodArgumentNotValidException and our GlobalExceptionHandler
 * answers 400 Bad Request with one message per invalid field.
 *
 * @Schema(example = ...) only fills in the sample JSON shown in Swagger UI.
 */
public record SignUpRequest(

        @Schema(example = "Meera Nair")
        @NotBlank(message = "Name is required")
        @Size(max = 100, message = "Name must be at most 100 characters")
        String name,

        @Schema(example = "meera@its.com")
        @NotBlank(message = "Email is required")
        @Email(message = "Email must be a valid email address")
        @Size(max = 255, message = "Email must be at most 255 characters")
        String email,

        @Schema(example = "Meera@123")
        @NotBlank(message = "Password is required")
        @Size(min = 8, max = 64, message = "Password must be 8 to 64 characters long")
        String password,

        @Schema(example = "https://example.com/images/meera.png", description = "Optional profile image URL")
        @Size(max = 255, message = "Profile image URL must be at most 255 characters")
        String profile,

        @Schema(example = "ASSIGNEE", description = "PROJECT_OWNER or ASSIGNEE")
        @NotNull(message = "Role is required (PROJECT_OWNER or ASSIGNEE)")
        Role role) {
}

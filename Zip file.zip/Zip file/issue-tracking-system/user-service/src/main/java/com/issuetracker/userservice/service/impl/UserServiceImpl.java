package com.issuetracker.userservice.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.issuetracker.userservice.client.IssueClient;
import com.issuetracker.userservice.client.IssueDto;
import com.issuetracker.userservice.dto.LoginRequest;
import com.issuetracker.userservice.dto.SignUpRequest;
import com.issuetracker.userservice.dto.UserResponse;
import com.issuetracker.userservice.entity.User;
import com.issuetracker.userservice.exception.DuplicateResourceException;
import com.issuetracker.userservice.exception.InvalidCredentialsException;
import com.issuetracker.userservice.exception.ResourceNotFoundException;
import com.issuetracker.userservice.repository.UserRepository;
import com.issuetracker.userservice.service.UserService;

/**
 * Business logic for users: sign-up, login and look-ups.
 *
 * The service layer holds the RULES (unique email, password hashing, credential check).
 * The controller only deals with HTTP, the repository only with the database.
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    /** Same message for unknown email and wrong password, so nobody can find out which emails exist. */
    private static final String INVALID_LOGIN_MESSAGE = "Invalid email or password";

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final IssueClient issueClient;

    /**
     * Constructor injection: Spring passes in the beans this class needs.
     * With a single constructor @Autowired is optional, but it is written here to make the
     * dependency injection visible. Fields can then be final, and a unit test can simply call
     * this constructor with mock objects.
     */
    @Autowired
    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, IssueClient issueClient) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.issueClient = issueClient;
    }

    @Override
    @Transactional
    public UserResponse signUp(SignUpRequest request) {
        // Normalise the input: no stray spaces, and emails compared in lower case
        String name = request.name().trim();
        String email = request.email().trim().toLowerCase();

        if (userRepository.existsByEmail(email)) {
            throw new DuplicateResourceException("A user with email '" + email + "' already exists");
        }
        if (userRepository.existsByNameIgnoreCase(name)) {
            throw new DuplicateResourceException("The name '" + name
                    + "' is already taken. Names must be unique because they are used as the username");
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        // BCrypt adds a random salt and hashes the password; only the hash is stored
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setProfile(blankToNull(request.profile()));
        user.setRole(request.role());

        User saved = userRepository.save(user);
        log.info("New user created: id={}, role={}", saved.getUserId(), saved.getRole());
        return UserResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse login(LoginRequest request) {
        String email = request.email().trim().toLowerCase();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new InvalidCredentialsException(INVALID_LOGIN_MESSAGE));

        // matches() hashes the typed password with the salt stored inside the hash and compares the results
        if (!passwordEncoder.matches(request.password(), user.getPassword())) {
            log.warn("Failed login attempt for user id={}", user.getUserId());
            throw new InvalidCredentialsException(INVALID_LOGIN_MESSAGE);
        }

        log.info("User id={} logged in", user.getUserId());
        return UserResponse.from(user);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(UserResponse::from)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserById(Integer userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + userId));
        return UserResponse.from(user);
    }

    // ---------- Milestone 5: inter-service communication ----------
    // These methods are deliberately NOT @Transactional: a database transaction should not stay open
    // while we wait for another service to answer over the network.

    @Override
    public List<IssueDto> getIssuesAssignedToUser(Integer userId) {
        // 1. Our own data: does the user exist? (404 if not - clearer than an empty list)
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found with id " + userId);
        }
        // 2. The Issue Service owns the issues, so we ask it (Feign call through Eureka)
        return issueClient.getIssuesByAssignee(userId);
    }

    @Override
    public List<IssueDto> getIssuesAssignedToUsername(String username) {
        User user = userRepository.findByNameIgnoreCase(username.trim())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with username '" + username + "'"));
        return issueClient.getIssuesByAssignee(user.getUserId());
    }

    /** Treats "" or "   " the same as "not given", so the database stores NULL instead of empty text. */
    private String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}

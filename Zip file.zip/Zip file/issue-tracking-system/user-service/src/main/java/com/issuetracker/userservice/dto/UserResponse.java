package com.issuetracker.userservice.dto;

import com.issuetracker.userservice.entity.Role;
import com.issuetracker.userservice.entity.User;

/**
 * What the API sends back for a user. It deliberately has NO password field,
 * so a password hash can never appear in a response.
 */
public record UserResponse(
        Integer userId,
        String name,
        String email,
        String profile,
        Role role) {

    /** Converts a database entity into the response shape. */
    public static UserResponse from(User user) {
        return new UserResponse(
                user.getUserId(),
                user.getName(),
                user.getEmail(),
                user.getProfile(),
                user.getRole());
    }
}

package com.issuetracker.userservice.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.issuetracker.userservice.client.IssueClient;
import com.issuetracker.userservice.client.IssueDto;
import com.issuetracker.userservice.dto.LoginRequest;
import com.issuetracker.userservice.dto.SignUpRequest;
import com.issuetracker.userservice.dto.UserResponse;
import com.issuetracker.userservice.entity.Role;
import com.issuetracker.userservice.entity.User;
import com.issuetracker.userservice.exception.DuplicateResourceException;
import com.issuetracker.userservice.exception.InvalidCredentialsException;
import com.issuetracker.userservice.exception.ResourceNotFoundException;
import com.issuetracker.userservice.repository.UserRepository;

/**
 * Unit tests for UserServiceImpl.
 *
 * The repository is a Mockito MOCK: a fake object whose answers we script with when(...).thenReturn(...).
 * So these tests never touch MySQL - they test only the business rules, and they run in milliseconds.
 * The password encoder is the real BCrypt one, so hashing and matching are tested for real.
 */
@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    /** Fake Feign client: no Issue Service needs to be running for these tests. */
    @Mock
    private IssueClient issueClient;

    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        // Same constructor Spring uses - this is why constructor injection makes testing easy
        userService = new UserServiceImpl(userRepository, passwordEncoder, issueClient);
    }

    /** Helper: a user as it would come back from the database. */
    private User existingUser(String rawPassword) {
        User user = new User();
        user.setUserId(1);
        user.setName("Priya Sharma");
        user.setEmail("priya@its.com");
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setRole(Role.PROJECT_OWNER);
        return user;
    }

    // ---------- sign up ----------

    @Test
    void signUp_validRequest_savesHashedPasswordAndLowerCaseEmail() {
        SignUpRequest request = new SignUpRequest("  Meera Nair ", "Meera@ITS.com", "Meera@123", "", Role.ASSIGNEE);
        when(userRepository.existsByEmail("meera@its.com")).thenReturn(false);
        when(userRepository.existsByNameIgnoreCase("Meera Nair")).thenReturn(false);
        // save() returns the same user with an id, like MySQL's AUTO_INCREMENT would
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User toSave = invocation.getArgument(0);
            toSave.setUserId(5);
            return toSave;
        });

        UserResponse response = userService.signUp(request);

        // Capture the User object that was passed to save() and check what would be stored
        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(captor.capture());
        User stored = captor.getValue();

        assertThat(stored.getName()).isEqualTo("Meera Nair");
        assertThat(stored.getEmail()).isEqualTo("meera@its.com");
        assertThat(stored.getPassword()).isNotEqualTo("Meera@123");          // not plain text
        assertThat(passwordEncoder.matches("Meera@123", stored.getPassword())).isTrue();
        assertThat(stored.getProfile()).isNull();                              // "" stored as NULL
        assertThat(response.userId()).isEqualTo(5);
        assertThat(response.role()).isEqualTo(Role.ASSIGNEE);
    }

    @Test
    void signUp_emailAlreadyUsed_throwsDuplicateAndDoesNotSave() {
        SignUpRequest request = new SignUpRequest("Someone New", "priya@its.com", "Password1", null, Role.ASSIGNEE);
        when(userRepository.existsByEmail("priya@its.com")).thenReturn(true);

        assertThatThrownBy(() -> userService.signUp(request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("priya@its.com");
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void signUp_nameAlreadyUsed_throwsDuplicateAndDoesNotSave() {
        SignUpRequest request = new SignUpRequest("Priya Sharma", "other@its.com", "Password1", null, Role.ASSIGNEE);
        when(userRepository.existsByEmail("other@its.com")).thenReturn(false);
        when(userRepository.existsByNameIgnoreCase("Priya Sharma")).thenReturn(true);

        assertThatThrownBy(() -> userService.signUp(request))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("already taken");
        verify(userRepository, never()).save(any(User.class));
    }

    // ---------- login ----------

    @Test
    void login_correctPassword_returnsUser() {
        when(userRepository.findByEmail("priya@its.com")).thenReturn(Optional.of(existingUser("Owner@123")));

        // Email typed with capitals still works, because it is lower-cased before the look-up
        UserResponse response = userService.login(new LoginRequest("Priya@ITS.com", "Owner@123"));

        assertThat(response.userId()).isEqualTo(1);
        assertThat(response.role()).isEqualTo(Role.PROJECT_OWNER);
    }

    @Test
    void login_wrongPassword_throwsInvalidCredentials() {
        when(userRepository.findByEmail("priya@its.com")).thenReturn(Optional.of(existingUser("Owner@123")));

        assertThatThrownBy(() -> userService.login(new LoginRequest("priya@its.com", "wrong-password")))
                .isInstanceOf(InvalidCredentialsException.class)
                .hasMessage("Invalid email or password");
    }

    @Test
    void login_unknownEmail_throwsSameInvalidCredentialsMessage() {
        when(userRepository.findByEmail("nobody@its.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.login(new LoginRequest("nobody@its.com", "whatever1")))
                .isInstanceOf(InvalidCredentialsException.class)
                .hasMessage("Invalid email or password");
    }

    // ---------- look-ups ----------

    @Test
    void getUserById_existingId_returnsUser() {
        when(userRepository.findById(1)).thenReturn(Optional.of(existingUser("Owner@123")));

        UserResponse response = userService.getUserById(1);

        assertThat(response.name()).isEqualTo("Priya Sharma");
    }

    @Test
    void getUserById_unknownId_throwsNotFound() {
        when(userRepository.findById(99)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.getUserById(99))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessage("User not found with id 99");
    }

    @Test
    void getAllUsers_returnsEveryUser() {
        when(userRepository.findAll()).thenReturn(List.of(existingUser("Owner@123")));

        List<UserResponse> users = userService.getAllUsers();

        assertThat(users).hasSize(1);
        assertThat(users.get(0).email()).isEqualTo("priya@its.com");
    }

    // ---------- Milestone 5: issues from the Issue Service ----------

    private IssueDto sampleIssue() {
        return new IssueDto(1, "Login page crashes", null, 1, 3, 1, "HIGH", "OPEN", "BUG",
                "Sprint 1", 3, "login", null, null);
    }

    @Test
    void getIssuesAssignedToUser_existingUser_returnsIssuesFromIssueService() {
        when(userRepository.existsById(3)).thenReturn(true);
        when(issueClient.getIssuesByAssignee(3)).thenReturn(List.of(sampleIssue()));

        List<IssueDto> issues = userService.getIssuesAssignedToUser(3);

        assertThat(issues).hasSize(1);
        assertThat(issues.get(0).summary()).isEqualTo("Login page crashes");
    }

    @Test
    void getIssuesAssignedToUser_unknownUser_throwsNotFoundWithoutCallingIssueService() {
        when(userRepository.existsById(99)).thenReturn(false);

        assertThatThrownBy(() -> userService.getIssuesAssignedToUser(99))
                .isInstanceOf(ResourceNotFoundException.class);
        verifyNoInteractions(issueClient);
    }

    @Test
    void getIssuesAssignedToUsername_findsUserByNameThenAsksIssueService() {
        User rahul = existingUser("Assignee@123");
        rahul.setUserId(3);
        when(userRepository.findByNameIgnoreCase("Rahul Verma")).thenReturn(Optional.of(rahul));
        when(issueClient.getIssuesByAssignee(3)).thenReturn(List.of(sampleIssue()));

        List<IssueDto> issues = userService.getIssuesAssignedToUsername("Rahul Verma");

        assertThat(issues).hasSize(1);
    }

    @Test
    void getIssuesAssignedToUsername_unknownName_throwsNotFound() {
        when(userRepository.findByNameIgnoreCase("Nobody")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.getIssuesAssignedToUsername("Nobody"))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Nobody");
        verifyNoInteractions(issueClient);
    }
}

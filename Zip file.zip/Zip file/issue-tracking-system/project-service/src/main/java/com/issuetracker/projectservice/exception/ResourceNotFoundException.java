package com.issuetracker.projectservice.exception;

/**
 * Thrown when something asked for by id or name does not exist (e.g. GET /api/projects/999).
 * GlobalExceptionHandler turns it into 404 Not Found.
 *
 * It extends RuntimeException (unchecked), so service methods do not need "throws" clauses.
 */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}

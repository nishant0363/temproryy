package com.issuetracker.projectservice.dto;

/**
 * Response of a successful create or update: a confirmation message plus the saved project
 * (which includes the project id, as the case study asks for "confirmation of project creation, project ID").
 */
public record ProjectSavedResponse(
        String message,
        ProjectResponse project) {
}

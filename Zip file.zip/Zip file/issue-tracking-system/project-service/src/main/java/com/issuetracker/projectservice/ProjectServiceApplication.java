package com.issuetracker.projectservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Entry point of the Project microservice (port 8082).
 *
 * It is a completely separate Spring Boot application from the User Service: its own process,
 * its own port and its own database (project_db). That is what makes it a microservice -
 * it can be built, started, tested and deployed on its own.
 *
 * @EnableFeignClients (Milestone 5): generate implementations for the @FeignClient interfaces (client.IssueClient).
 */
@SpringBootApplication
@EnableFeignClients
public class ProjectServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectServiceApplication.class, args);
    }
}

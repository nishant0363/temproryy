package com.issuetracker.projectservice.client;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * An issue as returned by the Issue Service (its IssueResponse JSON).
 *
 * Microservices share no code, so this service keeps its OWN copy of the shape it receives.
 * priority/status/type are plain Strings here: the Project Service only passes them on, it does not need
 * the Issue Service's enums. @JsonIgnoreProperties(ignoreUnknown = true) means that if the Issue Service
 * adds new fields later, this service keeps working instead of failing to read the JSON.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record IssueDto(
        Integer issueId,
        String summary,
        String description,
        Integer projectId,
        Integer assigneeId,
        Integer createdBy,
        String priority,
        String status,
        String type,
        String sprint,
        Integer storyPoint,
        String tags,
        LocalDate createdOn,
        LocalDate lastUpdated) {
}

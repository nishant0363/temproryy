package com.issuetracker.issueservice.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.FeignException;

import com.issuetracker.issueservice.client.ProjectClient;
import com.issuetracker.issueservice.client.ProjectDto;
import com.issuetracker.issueservice.client.UserClient;
import com.issuetracker.issueservice.client.UserDto;
import com.issuetracker.issueservice.dto.CreateIssueRequest;
import com.issuetracker.issueservice.dto.IssueResponse;
import com.issuetracker.issueservice.dto.UpdateIssueRequest;
import com.issuetracker.issueservice.entity.Issue;
import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;
import com.issuetracker.issueservice.exception.InvalidRequestException;
import com.issuetracker.issueservice.exception.ResourceNotFoundException;
import com.issuetracker.issueservice.repository.IssueRepository;

/**
 * Unit tests for IssueServiceImpl. The repository and the Feign clients are Mockito mocks, so neither MySQL
 * nor the User/Project services need to be running.
 */
@ExtendWith(MockitoExtension.class)
class IssueServiceImplTest {

    private static final UserDto PRIYA_OWNER = new UserDto(1, "Priya Sharma", "PROJECT_OWNER");
    private static final UserDto RAHUL_ASSIGNEE = new UserDto(3, "Rahul Verma", "ASSIGNEE");
    private static final UserDto ANANYA_ASSIGNEE = new UserDto(4, "Ananya Iyer", "ASSIGNEE");
    private static final ProjectDto CUSTOMER_PORTAL = new ProjectDto(1, "Customer Portal", 1);

    @Mock
    private IssueRepository issueRepository;

    @Mock
    private UserClient userClient;

    @Mock
    private ProjectClient projectClient;

    private IssueServiceImpl issueService;

    @BeforeEach
    void setUp() {
        issueService = new IssueServiceImpl(issueRepository, userClient, projectClient);
    }

    /** Scripts the other services' answers for a valid issue: project 1, creator 1 (owner), assignee 3. */
    private void otherServicesAcceptTheIssue() {
        when(projectClient.getProjectById(1)).thenReturn(CUSTOMER_PORTAL);
        when(userClient.getUserById(1)).thenReturn(PRIYA_OWNER);
        when(userClient.getUserById(3)).thenReturn(RAHUL_ASSIGNEE);
    }

    /** Helper: an issue as it would come back from the database. */
    private Issue existingIssue() {
        Issue issue = new Issue();
        issue.setId(1);
        issue.setSummary("Login page crashes");
        issue.setProjectId(1);
        issue.setCreatedBy(1);
        issue.setAssigneeId(3);
        issue.setPriority(Priority.HIGH);
        issue.setStatus(IssueStatus.OPEN);
        issue.setType(IssueType.BUG);
        issue.setStoryPoint(3);
        return issue;
    }

    /** An update request with only the given status set - every other field null ("leave unchanged"). */
    private UpdateIssueRequest statusOnly(IssueStatus status) {
        return new UpdateIssueRequest(null, null, null, null, status, null, null, null, null);
    }

    // ---------- create ----------

    @Test
    void createIssue_withoutOptionalFields_usesDefaults() {
        otherServicesAcceptTheIssue();
        when(issueRepository.save(any(Issue.class))).thenAnswer(invocation -> {
            Issue toSave = invocation.getArgument(0);
            toSave.setId(6);
            return toSave;
        });
        CreateIssueRequest request = new CreateIssueRequest(" Search is slow ", "  ", 1, 3, 1,
                Priority.MEDIUM, null, IssueType.TASK, null, null, " Backend, search,,backend ");

        IssueResponse response = issueService.createIssue(request);

        assertThat(response.issueId()).isEqualTo(6);
        assertThat(response.summary()).isEqualTo("Search is slow");   // trimmed
        assertThat(response.description()).isNull();                   // blank -> null
        assertThat(response.status()).isEqualTo(IssueStatus.OPEN);      // default
        assertThat(response.storyPoint()).isZero();                     // default
        assertThat(response.tags()).isEqualTo("backend,search");        // tidied
    }

    @Test
    void createIssue_withStatusGiven_keepsThatStatus() {
        otherServicesAcceptTheIssue();
        when(issueRepository.save(any(Issue.class))).thenAnswer(invocation -> invocation.getArgument(0));
        CreateIssueRequest request = new CreateIssueRequest("Write docs", null, 1, 3, 1,
                Priority.LOW, IssueStatus.IN_PROGRESS, IssueType.TASK, "Sprint 2", 2, null);

        IssueResponse response = issueService.createIssue(request);

        assertThat(response.status()).isEqualTo(IssueStatus.IN_PROGRESS);
        assertThat(response.storyPoint()).isEqualTo(2);
    }

    // ---------- Milestone 5: validation with the other services ----------

    private CreateIssueRequest validRequest(Integer projectId, Integer createdBy, Integer assigneeId) {
        return new CreateIssueRequest("Search is slow", null, projectId, assigneeId, createdBy,
                Priority.MEDIUM, null, IssueType.TASK, null, null, null);
    }

    @Test
    void createIssue_projectDoesNotExist_throwsInvalidRequestAndSavesNothing() {
        // thenThrow(SomeException.class): Mockito creates the exception object for us
        when(projectClient.getProjectById(99)).thenThrow(FeignException.NotFound.class);

        assertThatThrownBy(() -> issueService.createIssue(validRequest(99, 1, 3)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessage("projectId: no project exists with id 99");
        verify(issueRepository, never()).save(any(Issue.class));
    }

    @Test
    void createIssue_creatorIsAnAssignee_throwsInvalidRequest() {
        when(projectClient.getProjectById(1)).thenReturn(CUSTOMER_PORTAL);
        when(userClient.getUserById(3)).thenReturn(RAHUL_ASSIGNEE);

        assertThatThrownBy(() -> issueService.createIssue(validRequest(1, 3, 3)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("createdBy")
                .hasMessageContaining("must be PROJECT_OWNER");
        verify(issueRepository, never()).save(any(Issue.class));
    }

    @Test
    void createIssue_assigneeIsAProjectOwner_throwsInvalidRequest() {
        when(projectClient.getProjectById(1)).thenReturn(CUSTOMER_PORTAL);
        when(userClient.getUserById(1)).thenReturn(PRIYA_OWNER);

        assertThatThrownBy(() -> issueService.createIssue(validRequest(1, 1, 1)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("assigneeId")
                .hasMessageContaining("must be ASSIGNEE");
    }

    @Test
    void createIssue_assigneeDoesNotExist_throwsInvalidRequest() {
        when(projectClient.getProjectById(1)).thenReturn(CUSTOMER_PORTAL);
        when(userClient.getUserById(1)).thenReturn(PRIYA_OWNER);
        when(userClient.getUserById(99)).thenThrow(FeignException.NotFound.class);

        assertThatThrownBy(() -> issueService.createIssue(validRequest(1, 1, 99)))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessage("assigneeId: no user exists with id 99");
    }

    @Test
    void createIssue_userServiceDown_letsFeignExceptionThroughAndSavesNothing() {
        when(projectClient.getProjectById(1)).thenReturn(CUSTOMER_PORTAL);
        when(userClient.getUserById(1)).thenThrow(FeignException.ServiceUnavailable.class);

        // GlobalExceptionHandler turns this into 503 Service Unavailable
        assertThatThrownBy(() -> issueService.createIssue(validRequest(1, 1, 3)))
                .isInstanceOf(FeignException.class);
        verify(issueRepository, never()).save(any(Issue.class));
    }

    @Test
    void updateIssue_newAssignee_isCheckedWithUserService() {
        when(issueRepository.findById(1)).thenReturn(Optional.of(existingIssue()));   // assignee is 3
        when(userClient.getUserById(4)).thenReturn(ANANYA_ASSIGNEE);
        when(issueRepository.saveAndFlush(any(Issue.class))).thenAnswer(invocation -> invocation.getArgument(0));
        UpdateIssueRequest reassign = new UpdateIssueRequest(null, null, 4, null, null, null, null, null, null);

        IssueResponse response = issueService.updateIssue(1, reassign);

        assertThat(response.assigneeId()).isEqualTo(4);
    }

    @Test
    void updateIssue_onlyStatus_doesNotCallOtherServices() {
        when(issueRepository.findById(1)).thenReturn(Optional.of(existingIssue()));
        when(issueRepository.saveAndFlush(any(Issue.class))).thenAnswer(invocation -> invocation.getArgument(0));

        issueService.updateIssue(1, statusOnly(IssueStatus.RESOLVED));

        verifyNoInteractions(userClient, projectClient);
    }

    // ---------- read ----------

    @Test
    void getIssueById_unknownId_throwsNotFound() {
        when(issueRepository.findById(99)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> issueService.getIssueById(99))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessage("Issue not found with id 99");
    }

    @Test
    void getIssuesByAssignee_returnsThatAssigneesIssues() {
        when(issueRepository.findByAssigneeId(3)).thenReturn(List.of(existingIssue()));

        List<IssueResponse> issues = issueService.getIssuesByAssignee(3);

        assertThat(issues).hasSize(1);
        assertThat(issues.get(0).assigneeId()).isEqualTo(3);
    }

    // ---------- update ----------

    @Test
    void updateIssue_onlyStatusSent_changesOnlyStatus() {
        when(issueRepository.findById(1)).thenReturn(Optional.of(existingIssue()));
        when(issueRepository.saveAndFlush(any(Issue.class))).thenAnswer(invocation -> invocation.getArgument(0));

        IssueResponse response = issueService.updateIssue(1, statusOnly(IssueStatus.IN_PROGRESS));

        assertThat(response.status()).isEqualTo(IssueStatus.IN_PROGRESS);
        // everything else is unchanged
        assertThat(response.summary()).isEqualTo("Login page crashes");
        assertThat(response.assigneeId()).isEqualTo(3);
        assertThat(response.priority()).isEqualTo(Priority.HIGH);
    }

    @Test
    void updateIssue_emptyRequest_throwsInvalidRequestWithoutTouchingTheDatabase() {
        UpdateIssueRequest empty = new UpdateIssueRequest(null, null, null, null, null, null, null, null, null);

        assertThatThrownBy(() -> issueService.updateIssue(1, empty))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessage("Send at least one field to update");
        verifyNoInteractions(issueRepository);
    }

    @Test
    void updateIssue_blankSummary_throwsInvalidRequest() {
        when(issueRepository.findById(1)).thenReturn(Optional.of(existingIssue()));
        UpdateIssueRequest blankSummary = new UpdateIssueRequest("   ", null, null, null, null, null, null, null, null);

        assertThatThrownBy(() -> issueService.updateIssue(1, blankSummary))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessage("Summary cannot be blank");
        verify(issueRepository, never()).saveAndFlush(any(Issue.class));
    }

    @Test
    void updateIssue_unknownId_throwsNotFound() {
        when(issueRepository.findById(99)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> issueService.updateIssue(99, statusOnly(IssueStatus.CLOSED)))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- delete ----------

    @Test
    void deleteIssue_existingId_deletes() {
        when(issueRepository.existsById(1)).thenReturn(true);

        issueService.deleteIssue(1);

        verify(issueRepository).deleteById(1);
    }

    @Test
    void deleteIssue_unknownId_throwsNotFound() {
        when(issueRepository.existsById(99)).thenReturn(false);

        assertThatThrownBy(() -> issueService.deleteIssue(99))
                .isInstanceOf(ResourceNotFoundException.class);
        verify(issueRepository, never()).deleteById(any());
    }

    // ---------- helper ----------

    @Test
    void normalizeTags_onlyCommasAndSpaces_returnsNull() {
        assertThat(issueService.normalizeTags(" , ,, ")).isNull();
    }
}

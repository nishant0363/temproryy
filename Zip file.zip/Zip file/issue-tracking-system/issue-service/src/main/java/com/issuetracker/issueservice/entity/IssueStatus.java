package com.issuetracker.issueservice.entity;

/**
 * Where an issue is in its life cycle. Stored as text in a MySQL ENUM column (see Issue.status).
 * Assumed values. A new issue starts as OPEN unless another status is given.
 * (Named IssueStatus rather than Status to avoid confusion with HTTP status codes.)
 */
public enum IssueStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}

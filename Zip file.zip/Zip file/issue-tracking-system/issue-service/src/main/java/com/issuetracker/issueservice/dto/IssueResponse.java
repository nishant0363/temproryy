package com.issuetracker.issueservice.dto;

import java.time.LocalDate;

import com.issuetracker.issueservice.entity.Issue;
import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;

/**
 * What the API sends back for an issue. The other services (User, Project) receive this same JSON
 * when they ask for issues in Milestone 5.
 */
public record IssueResponse(
        Integer issueId,
        String summary,
        String description,
        Integer projectId,
        Integer assigneeId,
        Integer createdBy,
        Priority priority,
        IssueStatus status,
        IssueType type,
        String sprint,
        Integer storyPoint,
        String tags,
        LocalDate createdOn,
        LocalDate lastUpdated) {

    /** Converts a database entity into the response shape. */
    public static IssueResponse from(Issue issue) {
        return new IssueResponse(
                issue.getId(),
                issue.getSummary(),
                issue.getDescription(),
                issue.getProjectId(),
                issue.getAssigneeId(),
                issue.getCreatedBy(),
                issue.getPriority(),
                issue.getStatus(),
                issue.getType(),
                issue.getSprint(),
                issue.getStoryPoint(),
                issue.getTags(),
                issue.getCreatedOn(),
                issue.getLastUpdated());
    }
}

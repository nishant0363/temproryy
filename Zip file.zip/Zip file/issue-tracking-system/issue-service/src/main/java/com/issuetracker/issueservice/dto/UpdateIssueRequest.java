package com.issuetracker.issueservice.dto;

import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * JSON body of PUT /api/issues/{id}.
 *
 * Every field is OPTIONAL: only the fields present in the request are changed, the rest keep their
 * current value (a "partial update"). So an assignee can send just {"status": "IN_PROGRESS"}, and a
 * project owner can send {"assigneeId": 4, "priority": "HIGH"}.
 *
 * projectId and createdBy are deliberately missing: an issue cannot move to another project and its
 * creator never changes. If a client sends them anyway they are simply ignored.
 *
 * To clear an optional text field (description, sprint, tags), send it as an empty string "".
 */
public record UpdateIssueRequest(

        @Size(max = 255, message = "Summary must be at most 255 characters")
        String summary,

        @Size(max = 255, message = "Description must be at most 255 characters")
        String description,

        @Positive(message = "Assignee id must be a positive number")
        Integer assigneeId,

        Priority priority,

        IssueStatus status,

        IssueType type,

        @Size(max = 255, message = "Sprint must be at most 255 characters")
        String sprint,

        @Min(value = 0, message = "Story points cannot be negative")
        @Max(value = 100, message = "Story points must be at most 100")
        Integer storyPoint,

        @Size(max = 255, message = "Tags must be at most 255 characters")
        String tags) {

    /** True when the client sent no field at all (e.g. an empty body {}), so there is nothing to update. */
    public boolean hasNoChanges() {
        return summary == null && description == null && assigneeId == null && priority == null
                && status == null && type == null && sprint == null && storyPoint == null && tags == null;
    }
}

package com.issuetracker.issueservice.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.issuetracker.issueservice.entity.Issue;
import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;
import com.issuetracker.issueservice.repository.IssueRepository;

/**
 * Adds a few demo issues the first time the service starts (only when the issue table is EMPTY).
 * Saved straight through the repository, so start-up never depends on the other services being up.
 *
 * They use the demo users (1, 2 = project owners; 3, 4 = assignees) and demo projects (1, 2, 3)
 * of the User and Project services.
 */
@Component
public class DemoDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoDataLoader.class);

    private final IssueRepository issueRepository;

    @Autowired
    public DemoDataLoader(IssueRepository issueRepository) {
        this.issueRepository = issueRepository;
    }

    @Override
    public void run(String... args) {
        if (issueRepository.count() > 0) {
            log.info("Issues already exist - demo data not loaded");
            return;
        }

        // project, creator, assignee
        issueRepository.save(newIssue("Login page crashes on wrong password", "Stack trace shown instead of an error message",
                1, 1, 3, Priority.HIGH, IssueStatus.OPEN, IssueType.BUG, "Sprint 1", 3, "frontend,login"));
        issueRepository.save(newIssue("Add password reset by email", "Send a reset link valid for 30 minutes",
                1, 1, 4, Priority.MEDIUM, IssueStatus.IN_PROGRESS, IssueType.STORY, "Sprint 1", 5, "backend,email"));
        issueRepository.save(newIssue("Set up CI pipeline", "Build and run tests on every push",
                2, 1, 3, Priority.LOW, IssueStatus.RESOLVED, IssueType.TASK, "Sprint 1", 2, "devops"));
        issueRepository.save(newIssue("Stock count mismatch in reports", "Report total differs from warehouse count",
                3, 2, 4, Priority.CRITICAL, IssueStatus.OPEN, IssueType.BUG, "Sprint 2", 8, "reports,database"));
        issueRepository.save(newIssue("Barcode scanner integration", "Support USB barcode scanners at the counter",
                3, 2, 3, Priority.HIGH, IssueStatus.OPEN, IssueType.STORY, "Sprint 2", 5, "hardware"));

        log.info("Demo issues loaded (5 issues)");
    }

    private Issue newIssue(String summary, String description, int projectId, int createdBy, int assigneeId,
            Priority priority, IssueStatus status, IssueType type, String sprint, int storyPoint, String tags) {
        Issue issue = new Issue();
        issue.setSummary(summary);
        issue.setDescription(description);
        issue.setProjectId(projectId);
        issue.setCreatedBy(createdBy);
        issue.setAssigneeId(assigneeId);
        issue.setPriority(priority);
        issue.setStatus(status);
        issue.setType(type);
        issue.setSprint(sprint);
        issue.setStoryPoint(storyPoint);
        issue.setTags(tags);
        return issue;   // createdOn / lastUpdated are filled in by @PrePersist when saved
    }
}

package com.issuetracker.issueservice.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

/**
 * JPA entity = one row of the "issue" table in issue_db. Columns follow the DB design from the case study:
 * id, summary, description, project, assignee, created_by, priority, status, type, sprint, story_point,
 * tags, created_on, last_updated.
 *
 * project, assignee and created_by hold ids that live in OTHER services' databases (project_db, user_db),
 * so they are plain INT columns with no foreign keys. From Milestone 5 the service checks them by calling
 * the Project and User services before saving.
 *
 * Spring Boot maps Java camelCase names to snake_case columns automatically
 * (createdBy -> created_by, storyPoint -> story_point ...). @Column(name = ...) is only needed where the
 * Java name differs from the column name (projectId -> project, assigneeId -> assignee).
 */
@Entity
@Table(name = "issue")
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String summary;

    private String description;

    /** Id of the project this issue belongs to (project_db). */
    @Column(name = "project", nullable = false)
    private Integer projectId;

    /** Id of the user (an ASSIGNEE) who works on the issue (user_db). */
    @Column(name = "assignee", nullable = false)
    private Integer assigneeId;

    /** Id of the user (a PROJECT_OWNER) who created the issue - the issue's "owner". */
    @Column(nullable = false)
    private Integer createdBy;

    /** EnumType.STRING stores the NAME ("HIGH"), so re-ordering the enum can never corrupt data. */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueStatus status;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueType type;

    /** Free text, e.g. "Sprint 2". Optional. */
    private String sprint;

    /** Effort estimate. 0 when not estimated yet. */
    @Column(nullable = false)
    private Integer storyPoint;

    /** Comma-separated labels, e.g. "backend,login". Optional. */
    private String tags;

    /** Set by the server when the issue is first saved - never taken from the client. */
    @Column(nullable = false, updatable = false)
    private LocalDate createdOn;

    /** Set by the server every time the issue is changed. */
    @Column(nullable = false)
    private LocalDate lastUpdated;

    /** JPA needs a no-argument constructor to create objects from database rows. */
    public Issue() {
    }

    // ---------- JPA life-cycle callbacks ----------

    /** Runs automatically just BEFORE the first INSERT of this issue. */
    @PrePersist
    void onCreate() {
        LocalDate today = LocalDate.now();
        this.createdOn = today;
        this.lastUpdated = today;
    }

    /** Runs automatically just BEFORE every UPDATE of this issue. */
    @PreUpdate
    void onUpdate() {
        this.lastUpdated = LocalDate.now();
    }

    // ---------- getters and setters ----------

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getAssigneeId() {
        return assigneeId;
    }

    public void setAssigneeId(Integer assigneeId) {
        this.assigneeId = assigneeId;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public IssueStatus getStatus() {
        return status;
    }

    public void setStatus(IssueStatus status) {
        this.status = status;
    }

    public IssueType getType() {
        return type;
    }

    public void setType(IssueType type) {
        this.type = type;
    }

    public String getSprint() {
        return sprint;
    }

    public void setSprint(String sprint) {
        this.sprint = sprint;
    }

    public Integer getStoryPoint() {
        return storyPoint;
    }

    public void setStoryPoint(Integer storyPoint) {
        this.storyPoint = storyPoint;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public LocalDate getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDate createdOn) {
        this.createdOn = createdOn;
    }

    public LocalDate getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDate lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}

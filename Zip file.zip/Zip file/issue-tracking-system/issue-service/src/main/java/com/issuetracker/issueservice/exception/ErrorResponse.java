package com.issuetracker.issueservice.exception;

import java.time.LocalDateTime;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The single JSON shape used for EVERY error this service returns, for example:
 *
 * {
 *   "timestamp": "2026-10-01T10:15:30",
 *   "status": 404,
 *   "error": "Not Found",
 *   "message": "Issue not found with id 99",
 *   "path": "/api/issues/99"
 * }
 *
 * fieldErrors is only filled for validation failures (400) and is left out of the JSON otherwise
 * (@JsonInclude(NON_NULL) = do not write fields whose value is null).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorResponse(
        LocalDateTime timestamp,
        int status,
        String error,
        String message,
        String path,
        Map<String, String> fieldErrors) {
}

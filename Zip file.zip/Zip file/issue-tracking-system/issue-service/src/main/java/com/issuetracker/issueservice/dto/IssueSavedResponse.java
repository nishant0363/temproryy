package com.issuetracker.issueservice.dto;

/**
 * Response of a successful create or update: a confirmation message plus the saved issue
 * (which includes the issue id - "confirmation of issue creation, issue ID" in the case study).
 */
public record IssueSavedResponse(
        String message,
        IssueResponse issue) {
}

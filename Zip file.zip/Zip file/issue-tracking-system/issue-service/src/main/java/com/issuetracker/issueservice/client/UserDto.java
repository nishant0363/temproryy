package com.issuetracker.issueservice.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The part of the User Service's UserResponse JSON that this service needs to check creators and assignees.
 * Other fields are ignored (@JsonIgnoreProperties(ignoreUnknown = true)).
 * The role is a plain String because microservices share no code (no shared Role enum).
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record UserDto(
        Integer userId,
        String name,
        String role) {

    public static final String PROJECT_OWNER = "PROJECT_OWNER";
    public static final String ASSIGNEE = "ASSIGNEE";
}

package com.issuetracker.issueservice.dto;

import com.issuetracker.issueservice.entity.IssueStatus;
import com.issuetracker.issueservice.entity.IssueType;
import com.issuetracker.issueservice.entity.Priority;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * JSON body of POST /api/issues.
 *
 * Inputs from the case study: summary, project ID, description, priority, assignee ID, status,
 * created date, last updated date and comments. Differences (see README assumptions):
 *  - created/last-updated dates are NOT inputs: the server sets them, so clients cannot fake them
 *  - comments are left out (no Comment Service, no comments column in the DB design)
 *  - createdBy, type, sprint, storyPoint and tags come from the DB design
 */
public record CreateIssueRequest(

        @Schema(example = "Search returns duplicate results")
        @NotBlank(message = "Summary is required")
        @Size(max = 255, message = "Summary must be at most 255 characters")
        String summary,

        @Schema(example = "Searching for 'invoice' shows every result twice on the orders page")
        @Size(max = 255, message = "Description must be at most 255 characters")
        String description,

        @Schema(example = "1", description = "Id of the project the issue belongs to")
        @NotNull(message = "Project id is required")
        @Positive(message = "Project id must be a positive number")
        Integer projectId,

        @Schema(example = "3", description = "User id of the assignee (must be an ASSIGNEE)")
        @NotNull(message = "Assignee id is required")
        @Positive(message = "Assignee id must be a positive number")
        Integer assigneeId,

        @Schema(example = "1", description = "User id of the creator (must be a PROJECT_OWNER)")
        @NotNull(message = "Created-by user id is required")
        @Positive(message = "Created-by user id must be a positive number")
        Integer createdBy,

        @Schema(example = "MEDIUM", description = "LOW, MEDIUM, HIGH or CRITICAL")
        @NotNull(message = "Priority is required (LOW, MEDIUM, HIGH or CRITICAL)")
        Priority priority,

        @Schema(example = "OPEN", description = "Optional - OPEN if not given")
        IssueStatus status,

        @Schema(example = "BUG", description = "BUG, TASK or STORY")
        @NotNull(message = "Type is required (BUG, TASK or STORY)")
        IssueType type,

        @Schema(example = "Sprint 2")
        @Size(max = 255, message = "Sprint must be at most 255 characters")
        String sprint,

        @Schema(example = "3", description = "Optional - 0 if not given")
        @Min(value = 0, message = "Story points cannot be negative")
        @Max(value = 100, message = "Story points must be at most 100")
        Integer storyPoint,

        @Schema(example = "search,backend", description = "Optional comma-separated labels")
        @Size(max = 255, message = "Tags must be at most 255 characters")
        String tags) {
}

package com.issuetracker.issueservice.entity;

/**
 * How urgent an issue is. Stored as text in a MySQL ENUM column (see Issue.priority).
 * Assumed values - the case study only says the column is an ENUM.
 */
public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

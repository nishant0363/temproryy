package com.issuetracker.issueservice.exception;

/**
 * Thrown when a request is well-formed JSON but breaks a business rule that annotations cannot express,
 * e.g. an update request that contains no fields. GlobalExceptionHandler turns it into 400 Bad Request.
 */
public class InvalidRequestException extends RuntimeException {

    public InvalidRequestException(String message) {
        super(message);
    }
}
